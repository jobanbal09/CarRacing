﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using CarRacing;

namespace UnitTesting
{
    [TestClass]
    public class UnitTest1
    {
        MainForm objCar = new MainForm();
        [TestMethod]
        public void CarRaceTesting()
        {
            objCar.CarsRaceRun();
        }
    }
}
